function varargout = GUI(varargin)
% GUI MATLAB code for GUI.fig
%      GUI, by itself, creates a new GUI or raises the existing
%      singleton*.
%
%      H = GUI returns the handle to a new GUI or the handle to
%      the existing singleton*.
%
%      GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI.M with the given input arguments.
%
%      GUI('Property','Value',...) creates a new GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI

% Last Modified by GUIDE v2.5 10-Jan-2018 16:47:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI is made visible.
function GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI (see VARARGIN)

% Choose default command line output for GUI
handles.output = hObject;
set(handles.edit1,'String','')
set(handles.edit2,'String','')
set(handles.edit3,'String','')
axes(handles.axes1)
axes(handles.axes2)
axes(handles.axes3)

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a=handles.str;
[A,V,P,t,sensores,G]=cadera(a);
if isempty(str2num(get(handles.edit4,'string')))
    sensor=1;
else
    sensor=round(str2num(get(handles.edit4,'string')))
end
if sensor>sensores
    sensor=sensores
end
if sensor<1
    sensor=1
end
if isempty(str2num(get(handles.edit2,'string')))
    cti=1;
else
    ti=str2num(get(handles.edit2,'string'))
    cti=tiempo(ti,t);
end
if isempty(str2num(get(handles.edit3,'string')))
    ctf=length(t);
else
    tf=str2num(get(handles.edit3,'string'));
    ctf=tiempo(tf,t);
end
cla(handles.axes1)
cla(handles.axes2)
cla(handles.axes3)

axes(handles.axes1);
plot(t(cti:ctf),A(1,cti:ctf,sensor),'r')
hold on
plot(t(cti:ctf),A(2,cti:ctf,sensor),'b')
plot(t(cti:ctf),A(3,cti:ctf,sensor),'g')
legend('Eje x','Eje y','Eje z')
title(['Sensor ',num2str(sensor)])
%xlabel('Tiempo[s]')
ylabel('Aceleraci�n[m/s2]')
set(gca,'XTick',[])
axes(handles.axes2);
plot(t(cti:ctf),V(1,cti:ctf,sensor),'r')
hold on
plot(t(cti:ctf),V(2,cti:ctf,sensor),'b')
plot(t(cti:ctf),V(3,cti:ctf,sensor),'g')
%xlabel('Tiempo[s]')
ylabel('Velocidad[m/s]')
set(gca,'XTick',[])
%legend('Velocidad x','Velocidad y','Velocidad z')
axes(handles.axes3);
plot(t(cti:ctf),P(1,cti:ctf,sensor),'r')
hold on
plot(t(cti:ctf),P(2,cti:ctf,sensor),'b')
plot(t(cti:ctf),P(3,cti:ctf,sensor),'g')
xlabel('Tiempo[s]')
ylabel('Posici�n[m]')
%legend('Posici�n x','Posici�n y','Posici�n z')
guidata(gcbo,handles);

function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
str=get(hObject,'String');
handles.str = str;
guidata(gcbo,handles);

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double




% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cla(handles.axes1)
cla(handles.axes2)
cla(handles.axes3)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
e=handles.str;
[A1,V1,P1,t1,sensores,G]=cadera(e);
if isempty(str2num(get(handles.edit4,'string')))
    sensor=1;
else
    sensor=round(str2num(get(handles.edit4,'string')))
end
if sensor>sensores
    sensor=sensores;
end
if sensor<1
    sensor=1;
end
if isempty(str2num(get(handles.edit2,'string')))
    cti1=1;
else
    ti1=str2num(get(handles.edit2,'string'))
    cti1=tiempo(ti1,t1)
end
if isempty(str2num(get(handles.edit3,'string')))
    ctf1=length(t1);
else
    tf1=str2num(get(handles.edit3,'string'))
    ctf1=tiempo(tf1,t1)
end

cla(handles.axes1)
cla(handles.axes2)
cla(handles.axes3)
An=norma(A1);
Vn=norma(V1);
Pn=norma(P1);

axes(handles.axes1);
legend(handles.axes1,'hide')
plot(t1(cti1:ctf1),An(cti1:ctf1,sensor),'r')
title(['Sensor ',num2str(sensor)])
ylabel('Aceleraci�n[m/s2]')
set(gca,'XTick',[])
axes(handles.axes2);
plot(t1(cti1:ctf1),Vn(cti1:ctf1,sensor),'g')
ylabel('Velocidad[m/s]')
set(gca,'XTick',[])
axes(handles.axes3);
plot(t1(cti1:ctf1),Pn(cti1:ctf1,sensor),'b')
xlabel('Tiempo[s]')
ylabel('Posici�n[m]')
guidata(gcbo,handles);



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
b=handles.str;
[A,V,P,t,sensores,G]=cadera(b);
if isempty(str2num(get(handles.edit4,'string')))
    sensor=1;
else
    sensor=round(str2num(get(handles.edit4,'string')))
end
if sensor>sensores
    sensor=sensores;
end
if sensor<1
    sensor=1
end
if isempty(str2num(get(handles.edit2,'string')))
    cti=1;
else
    ti=str2num(get(handles.edit2,'string'))
    cti=tiempo(ti,t)
end
if isempty(str2num(get(handles.edit3,'string')))
    ctf=length(t);
else
    tf=str2num(get(handles.edit3,'string'))
    ctf=tiempo(tf,t)
end
cla(handles.axes1)
cla(handles.axes2)
cla(handles.axes3)

axes(handles.axes1);
plot(t(cti:ctf),G(1,cti:ctf,sensor),'r')
hold on
plot(t(cti:ctf),G(2,cti:ctf,sensor),'b')
plot(t(cti:ctf),G(3,cti:ctf,sensor),'g')
legend('Eje x','Eje y','Eje z')
title(['Sensor ',num2str(sensor)])
%xlabel('Tiempo[s]')
ylabel('Vel.Angular[grad/s]')
set(gca,'XTick',[])
axes(handles.axes2);
plot(t(cti:ctf),V(1,cti:ctf,sensor),'r')
hold on
plot(t(cti:ctf),V(2,cti:ctf,sensor),'b')
plot(t(cti:ctf),V(3,cti:ctf,sensor),'g')
%xlabel('Tiempo[s]')
ylabel('Velocidad[m/s]')
set(gca,'XTick',[])
%legend('Velocidad x','Velocidad y','Velocidad z')
axes(handles.axes3);
plot(t(cti:ctf),P(1,cti:ctf,sensor),'r')
hold on
plot(t(cti:ctf),P(2,cti:ctf,sensor),'b')
plot(t(cti:ctf),P(3,cti:ctf,sensor),'g')
xlabel('Tiempo[s]')
ylabel('Posici�n[m]')
%legend('Posici�n x','Posici�n y','Posici�n z')
guidata(gcbo,handles);


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
c=handles.str;
[A,V,P,t,sensores,G,Mag,tmag]=cadera(c);
if isempty(str2num(get(handles.edit4,'string')))
    sensor=1;
else
    sensor=round(str2num(get(handles.edit4,'string')));
end
if sensor>sensores
    sensor=sensores;
end
if sensor<1
    sensor=1;
end
if isempty(str2num(get(handles.edit2,'string')))
    cti=1;
else
    ti=str2num(get(handles.edit2,'string'))
    cti=tiempo(ti,tmag);
end
if isempty(str2num(get(handles.edit3,'string')))
    ctf=length(tmag);
else
    tf=str2num(get(handles.edit3,'string'))
    ctf=tiempo(tf,tmag)
end
cla(handles.axes1)
cla(handles.axes2)
cla(handles.axes3)

axes(handles.axes1);
plot(tmag(cti:ctf),Mag(1,cti:ctf,sensor),'r')
hold on
plot(tmag(cti:ctf),Mag(2,cti:ctf,sensor),'b')
plot(tmag(cti:ctf),Mag(3,cti:ctf,sensor),'g')
legend('Eje x','Eje y','Eje z')
title(['Sensor ',num2str(sensor)])
%xlabel('Tiempo[s]')
ylabel('Tesla')
%set(gca,'XTick',[])
% axes(handles.axes2);
% plot(t(cti:ctf),V(1,cti:ctf,sensor),'r')
% hold on
% plot(t(cti:ctf),V(2,cti:ctf,sensor),'b')
% plot(t(cti:ctf),V(3,cti:ctf,sensor),'g')
%xlabel('Tiempo[s]')
% ylabel('Velocidad[m/s]')
% set(gca,'XTick',[])
% %legend('Velocidad x','Velocidad y','Velocidad z')
% axes(handles.axes3);
% plot(t(cti:ctf),P(1,cti:ctf,sensor),'r')
% hold on
% plot(t(cti:ctf),P(2,cti:ctf,sensor),'b')
% plot(t(cti:ctf),P(3,cti:ctf,sensor),'g')
% xlabel('Tiempo[s]')
% ylabel('Posici�n[m]')
% %legend('Posici�n x','Posici�n y','Posici�n z')
guidata(gcbo,handles);